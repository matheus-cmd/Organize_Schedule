/**
 * calendar.js — StudyFlow
 * Módulo do calendário mensal visual + integração Google Calendar.
 *
 * Google Calendar:
 *  - Para integração real, configure CLIENT_ID e API_KEY abaixo.
 *  - A implementação usa a Google Identity Services (GIS) e
 *    a Google Calendar REST API v3.
 *  - Em ambiente de demonstração, o fluxo simula a autenticação.
 */

/* ============================================================
   CONFIGURAÇÃO GOOGLE CALENDAR
   ============================================================
   Para ativar:
   1. Acesse https://console.cloud.google.com/
   2. Crie um projeto e ative a Google Calendar API.
   3. Crie credenciais OAuth 2.0 (aplicativo da Web).
   4. Preencha CLIENT_ID e API_KEY abaixo.
   5. Adicione o domínio às origens autorizadas.
   ============================================================ */
const GOOGLE_CLIENT_ID = '924205271554-n9m2vl3bc7i8rjijj20ncee6itrksahs.apps.googleusercontent.com'; // ← substitua
const GOOGLE_API_KEY   = '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';                               // ← substitua
const GOOGLE_SCOPES    = 'https://www.googleapis.com/auth/calendar';
const GOOGLE_DISCOVERY = 'https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest';
const DEMO_MODE        = false; // false = integração real, true = simulação

/* ============================================================
   ESTADO DO CALENDÁRIO
   ============================================================ */
const CalState = {
  year:  new Date().getFullYear(),
  month: new Date().getMonth(), // 0-based
  googleUser: null,
  googleToken: null,
  gapiInited: false,
  gisInited:  false,
};

/* ============================================================
   CALENDÁRIO MENSAL
   ============================================================ */

/**
 * Renderiza o calendário mensal na view "calendar".
 */
function renderCalendar() {
  const grid = document.getElementById('calendarGrid');
  if (!grid) return;

  const events = window.AppEvents ? AppEvents.getEvents() : [];

  // Atualiza título
  const monthNames = [
    'Janeiro','Fevereiro','Março','Abril','Maio','Junho',
    'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'
  ];
  document.getElementById('calMonthYear').textContent =
    `${monthNames[CalState.month]} ${CalState.year}`;

  grid.innerHTML = '';

  // Cabeçalho: dias da semana
  const weekDays = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
  weekDays.forEach(d => {
    const hdr = document.createElement('div');
    hdr.className = 'cal-day-header';
    hdr.textContent = d;
    grid.appendChild(hdr);
  });

  // Primeiro dia do mês e total de dias
  const firstDay = new Date(CalState.year, CalState.month, 1).getDay(); // 0=Dom
  const daysInMonth = new Date(CalState.year, CalState.month + 1, 0).getDate();
  const daysInPrev  = new Date(CalState.year, CalState.month, 0).getDate();

  // Hoje
  const todayDate = new Date();
  todayDate.setHours(0, 0, 0, 0);

  /**
   * Cria uma célula de dia.
   * @param {number} day  Número do dia
   * @param {boolean} isCurrentMonth
   */
  function createDayCell(day, isCurrentMonth) {
    const cell = document.createElement('div');
    const cellDate = new Date(
      isCurrentMonth ? CalState.year : (firstDay === 0 ? CalState.year : CalState.year),
      isCurrentMonth ? CalState.month : (day < 20 ? CalState.month + 1 : CalState.month - 1),
      day
    );
    cellDate.setHours(0, 0, 0, 0);

    cell.className = `cal-day${!isCurrentMonth ? ' other-month' : ''}`;
    if (isCurrentMonth && cellDate.getTime() === todayDate.getTime()) {
      cell.classList.add('today');
    }

    const num = document.createElement('div');
    num.className = 'cal-day-num';
    num.textContent = day;
    cell.appendChild(num);

    // Eventos deste dia
    if (isCurrentMonth) {
      const dayStr = `${CalState.year}-${String(CalState.month + 1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
      const dayEvents = events.filter(e => e.date === dayStr);

      dayEvents.slice(0, 3).forEach(ev => {
        const dot = document.createElement('div');
        dot.className = `cal-event-dot dot-${ev.type || 'outro'}`;
        dot.style.background = getTypeColor(ev.type);
        dot.style.color = '#fff';
        dot.textContent = ev.title;
        dot.title = `${ev.title} — ${window.AppEvents ? AppEvents.TYPE_LABELS[ev.type] : ev.type}`;
        cell.appendChild(dot);
      });

      if (dayEvents.length > 3) {
        const more = document.createElement('div');
        more.className = 'cal-event-dot';
        more.style.background = 'var(--text-muted)';
        more.style.color = '#fff';
        more.textContent = `+${dayEvents.length - 3} mais`;
        cell.appendChild(more);
      }
    }

    return cell;
  }

  // Dias do mês anterior
  for (let i = firstDay - 1; i >= 0; i--) {
    grid.appendChild(createDayCell(daysInPrev - i, false));
  }

  // Dias do mês atual
  for (let d = 1; d <= daysInMonth; d++) {
    grid.appendChild(createDayCell(d, true));
  }

  // Dias do próximo mês para completar grade (6 linhas × 7 = 42 células)
  const totalCells = firstDay + daysInMonth;
  const remaining  = totalCells <= 35 ? 35 - totalCells : 42 - totalCells;
  for (let d = 1; d <= remaining; d++) {
    grid.appendChild(createDayCell(d, false));
  }
}

/** Retorna a cor CSS de um tipo de evento */
function getTypeColor(type) {
  const colors = {
    prova:        'var(--prova)',
    trabalho:     'var(--trabalho)',
    entrega:      'var(--entrega)',
    apresentacao: 'var(--apresentacao)',
    outro:        'var(--outro)',
  };
  return colors[type] || colors.outro;
}

/* ============================================================
   NAVEGAÇÃO NO CALENDÁRIO
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  // Botões de navegação
  document.getElementById('calPrev')?.addEventListener('click', () => {
    CalState.month--;
    if (CalState.month < 0) { CalState.month = 11; CalState.year--; }
    renderCalendar();
  });

  document.getElementById('calNext')?.addEventListener('click', () => {
    CalState.month++;
    if (CalState.month > 11) { CalState.month = 0; CalState.year++; }
    renderCalendar();
  });
});

/* ============================================================
   GOOGLE CALENDAR — INTEGRAÇÃO
   ============================================================ */

/**
 * Inicializa a integração com Google Calendar.
 * Em DEMO_MODE simula login/logout sem chamar a API real.
 */
function initGoogleCalendar() {
  const btnSignIn  = document.getElementById('btnGoogleSignIn');
  const btnSignOut = document.getElementById('btnGoogleSignOut');
  const btnExport  = document.getElementById('btnExportGoogle');
  const btnImport  = document.getElementById('btnImportGoogle');

  if (!btnSignIn) return;

  // Verifica se havia sessão salva (demo)
  const savedGoogleUser = localStorage.getItem('studyflow_google_user');
  if (savedGoogleUser) {
    try {
      CalState.googleUser = JSON.parse(savedGoogleUser);
      showGoogleConnected(CalState.googleUser);
    } catch { /* ignora */ }
  }

  btnSignIn.addEventListener('click', () => {
    if (DEMO_MODE) {
      // Simula login
      const demoUser = {
        name:  'Estudante Demo',
        email: 'estudante@gmail.com',
        photo: null,
      };
      CalState.googleUser = demoUser;
      localStorage.setItem('studyflow_google_user', JSON.stringify(demoUser));
      showGoogleConnected(demoUser);
      window.showToast('Conta Google conectada (modo demo)!', 'success');
    } else {
      // Integração real via GIS
      realGoogleSignIn();
    }
  });

  btnSignOut?.addEventListener('click', () => {
    CalState.googleUser = null;
    CalState.googleToken = null;
    localStorage.removeItem('studyflow_google_user');
    showGoogleDisconnected();
    window.showToast('Conta Google desconectada.', 'info');
  });

  btnExport?.addEventListener('click', handleExportToGoogle);
  btnImport?.addEventListener('click', handleImportFromGoogle);
}

/** Mostra área de conta conectada */
function showGoogleConnected(user) {
  const authArea  = document.getElementById('googleAuthArea');
  const syncArea  = document.getElementById('googleSyncArea');
  const userInfo  = document.getElementById('googleUserInfo');

  if (authArea)  authArea.style.display  = 'none';
  if (syncArea)  syncArea.style.display  = 'block';
  if (userInfo) {
    userInfo.innerHTML = `
      ${user.photo ? `<img src="${user.photo}" alt="Foto">` : `<div style="width:36px;height:36px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;flex-shrink:0">${user.name.charAt(0)}</div>`}
      <div>
        <div class="google-user-name">${escapeHtmlLocal(user.name)}</div>
        <div class="google-user-email">${escapeHtmlLocal(user.email)}</div>
      </div>
    `;
  }
}

/** Mostra área de login */
function showGoogleDisconnected() {
  const authArea = document.getElementById('googleAuthArea');
  const syncArea = document.getElementById('googleSyncArea');
  if (authArea) authArea.style.display = 'block';
  if (syncArea) syncArea.style.display = 'none';
}

/* ============================================================
   EXPORTAR PARA GOOGLE CALENDAR
   ============================================================ */

async function handleExportToGoogle() {
  const events = window.AppEvents ? AppEvents.getEvents() : [];
  if (!events.length) {
    window.showToast('Nenhum evento para exportar.', 'warn');
    return;
  }

  if (DEMO_MODE) {
    // Simula exportação
    await sleep(1000);
    window.showToast(`${events.length} evento(s) exportado(s) para o Google Agenda (demo)!`, 'success');
    return;
  }

  // Integração real
  try {
    let exported = 0;
    for (const ev of events) {
      await createGoogleEvent(ev);
      exported++;
    }
    window.showToast(`${exported} evento(s) exportado(s) com sucesso!`, 'success');
  } catch (e) {
    console.error('[Google Calendar] Erro na exportação:', e);
    window.showToast('Erro ao exportar eventos. Verifique as credenciais.', 'error');
  }
}

/**
 * Cria um evento no Google Calendar via REST API.
 * @param {Object} ev  Evento local
 */
async function createGoogleEvent(ev) {
  if (!CalState.googleToken) throw new Error('Não autenticado.');

  const start = buildGoogleDateTime(ev.date, ev.time);
  const end   = buildGoogleDateTimeEnd(ev.date, ev.time);

  const body = {
    summary:     ev.title,
    description: `[${window.AppEvents?.TYPE_LABELS[ev.type] || ev.type}] ${ev.discipline}\n\n${ev.description || ''}`.trim(),
    start,
    end,
  };

  const res = await fetch(
    'https://www.googleapis.com/calendar/v3/calendars/primary/events',
    {
      method:  'POST',
      headers: {
        'Authorization': `Bearer ${CalState.googleToken}`,
        'Content-Type':  'application/json',
      },
      body: JSON.stringify(body),
    }
  );

  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

function buildGoogleDateTime(dateStr, timeStr) {
  if (timeStr) {
    return { dateTime: `${dateStr}T${timeStr}:00`, timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone };
  }
  return { date: dateStr };
}

function buildGoogleDateTimeEnd(dateStr, timeStr) {
  if (timeStr) {
    // Adiciona 1 hora
    const [hh, mm] = timeStr.split(':').map(Number);
    const end = new Date(`${dateStr}T${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}:00`);
    end.setHours(end.getHours() + 1);
    const endStr = end.toISOString().slice(0,16);
    return { dateTime: `${endStr}:00`, timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone };
  }
  // Dia inteiro: end = próximo dia
  const d = new Date(dateStr);
  d.setDate(d.getDate() + 1);
  return { date: d.toISOString().slice(0,10) };
}

/* ============================================================
   IMPORTAR DO GOOGLE CALENDAR
   ============================================================ */

async function handleImportFromGoogle() {
  if (DEMO_MODE) {
    // Simula importação com eventos fictícios
    await sleep(1200);

    const demoImports = [
      {
        title:       'Prova de Física Quântica',
        discipline:  'Física',
        type:        'prova',
        date:        getRelativeDate(5),
        time:        '14:00',
        description: 'Importado do Google Agenda (demo)',
        reminders:   [],
      },
      {
        title:       'Entrega de Relatório de Química',
        discipline:  'Química',
        type:        'entrega',
        date:        getRelativeDate(10),
        time:        '23:59',
        description: 'Importado do Google Agenda (demo)',
        reminders:   [],
      },
    ];

    let imported = 0;
    if (window.AppEvents) {
      const existing = AppEvents.getEvents();
      demoImports.forEach(imp => {
        // Evita duplicata por título+data
        const dup = existing.find(e => e.title === imp.title && e.date === imp.date);
        if (!dup) {
          // Chama saveEvent via app.js
          window.dispatchEvent(new CustomEvent('studyflow:importEvent', { detail: imp }));
          imported++;
        }
      });
    }

    window.showToast(
      imported
        ? `${imported} evento(s) importado(s) do Google Agenda (demo)!`
        : 'Nenhum evento novo para importar.',
      imported ? 'success' : 'info'
    );
    return;
  }

  // Integração real
  try {
    const items = await fetchGoogleEvents();
    let imported = 0;

    items.forEach(item => {
      const ev = convertGoogleEvent(item);
      if (ev) {
        window.dispatchEvent(new CustomEvent('studyflow:importEvent', { detail: ev }));
        imported++;
      }
    });

    window.showToast(`${imported} evento(s) importado(s)!`, 'success');
  } catch (e) {
    console.error('[Google Calendar] Erro na importação:', e);
    window.showToast('Erro ao importar eventos.', 'error');
  }
}

/** Busca eventos dos próximos 30 dias no Google Calendar */
async function fetchGoogleEvents() {
  if (!CalState.googleToken) throw new Error('Não autenticado.');

  const now     = new Date().toISOString();
  const future  = new Date(Date.now() + 30 * 86400000).toISOString();

  const url = `https://www.googleapis.com/calendar/v3/calendars/primary/events?` +
    `timeMin=${encodeURIComponent(now)}&timeMax=${encodeURIComponent(future)}&singleEvents=true&orderBy=startTime`;

  const res = await fetch(url, {
    headers: { 'Authorization': `Bearer ${CalState.googleToken}` },
  });

  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  return data.items || [];
}

/** Converte evento Google para formato local */
function convertGoogleEvent(item) {
  if (!item.summary) return null;

  const dateStr = item.start?.date || item.start?.dateTime?.slice(0,10);
  const timeStr = item.start?.dateTime ? item.start.dateTime.slice(11,16) : '';

  return {
    title:       item.summary,
    discipline:  'Google Agenda',
    type:        'outro',
    date:        dateStr || '',
    time:        timeStr,
    description: item.description || '',
    reminders:   [],
  };
}

/* ============================================================
   GOOGLE SIGN-IN REAL (GIS)
   ============================================================ */

function realGoogleSignIn() {
  if (!window.google) {
    // Carrega a lib GIS dinamicamente
    const script = document.createElement('script');
    script.src = 'https://accounts.google.com/gsi/client';
    script.onload = () => initGIS();
    document.head.appendChild(script);
    return;
  }
  initGIS();
}

function initGIS() {
  if (!window.google?.accounts) {
    window.showToast('Google Identity Services não disponível.', 'error');
    return;
  }

  const client = google.accounts.oauth2.initTokenClient({
    client_id: GOOGLE_CLIENT_ID,
    scope:     GOOGLE_SCOPES,
    callback:  (response) => {
      if (response.error) {
        window.showToast('Falha na autenticação Google.', 'error');
        return;
      }
      CalState.googleToken = response.access_token;

      // Busca perfil do usuário
      fetchGoogleProfile(response.access_token).then(profile => {
        CalState.googleUser = profile;
        localStorage.setItem('studyflow_google_user', JSON.stringify(profile));
        showGoogleConnected(profile);
        window.showToast('Conta Google conectada!', 'success');
      });
    },
  });

  client.requestAccessToken();
}

async function fetchGoogleProfile(token) {
  try {
    const res  = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { 'Authorization': `Bearer ${token}` },
    });
    const data = await res.json();
    return { name: data.name, email: data.email, photo: data.picture };
  } catch {
    return { name: 'Usuário Google', email: '', photo: null };
  }
}

/* ============================================================
   LISTENER: IMPORTAR EVENTO VIA EVENTO CUSTOM
   ============================================================ */
window.addEventListener('studyflow:importEvent', e => {
  const ev = e.detail;
  if (!ev) return;

  // Injeta diretamente no AppState (sem modal)
  if (window.AppState && window.AppEvents) {
    const id = Date.now().toString(36) + Math.random().toString(36).slice(2);
    const newEv = {
      id,
      ...ev,
      done:      false,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    AppState.events.push(newEv);
    localStorage.setItem('studyflow_events', JSON.stringify(AppState.events));
    AppEvents.refreshAll();
  }
});

/* ============================================================
   UTILITÁRIOS LOCAIS
   ============================================================ */

function escapeHtmlLocal(str) {
  return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/** Retorna data 'YYYY-MM-DD' relativa a hoje + N dias */
function getRelativeDate(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0,10);
}

function sleep(ms) {
  return new Promise(res => setTimeout(res, ms));
}

/* ============================================================
   INICIALIZAÇÃO
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  initGoogleCalendar();
});

// Exposição pública
window.CalendarModule = {
  render: renderCalendar,
  state:  CalState,
};