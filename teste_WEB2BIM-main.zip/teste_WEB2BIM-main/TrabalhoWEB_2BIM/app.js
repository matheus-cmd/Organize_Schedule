/**
 * app.js — StudyFlow
 * Lógica principal: CRUD de eventos, dashboard, filtros, views.
 * Armazena dados em localStorage.
 */

/* ============================================================
   ESTADO GLOBAL
   ============================================================ */
const App = {
  events: [],          // Array de eventos
  editingId: null,     // ID do evento em edição
  currentView: 'dashboard',
  filters: {
    search: '',
    type: '',
    status: '',
    discipline: '',
  },
};

/* ============================================================
   UTILITÁRIOS
   ============================================================ */

/** Gera ID único */
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2);
}

/** Retorna data/hora atual como objeto Date normalizado (meia-noite) */
function today() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

/** Converte string 'YYYY-MM-DD' para Date (meia-noite local) */
function parseDate(str) {
  if (!str) return null;
  const [y, m, d] = str.split('-').map(Number);
  return new Date(y, m - 1, d);
}

/** Formata Date para 'DD/MM/YYYY' */
function formatDate(d) {
  if (!d) return '—';
  const dt = typeof d === 'string' ? parseDate(d) : d;
  if (!dt) return '—';
  return dt.toLocaleDateString('pt-BR');
}

/** Formata horário '14:30' → '14h30' */
function formatTime(t) {
  if (!t) return '';
  return t.replace(':', 'h');
}

/** Dias restantes até a data do evento (negativo = atrasado) */
function daysUntil(dateStr) {
  const dt = parseDate(dateStr);
  if (!dt) return null;
  const diff = dt - today();
  return Math.round(diff / 86400000);
}

/** Retorna o status do evento */
function eventStatus(ev) {
  if (ev.done) return 'done';
  const d = daysUntil(ev.date);
  if (d === null) return 'pending';
  if (d < 0) return 'overdue';
  return 'pending';
}

/** Capitaliza primeira letra */
function cap(str) {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
}

/** Nomes legíveis de tipo */
const TYPE_LABELS = {
  prova: 'Prova',
  trabalho: 'Trabalho',
  entrega: 'Entrega',
  apresentacao: 'Apresentação',
  outro: 'Outro',
};

/* ============================================================
   LOCALSTORAGE
   ============================================================ */
const STORAGE_KEY = 'studyflow_events';

/** Carrega eventos do localStorage */
function loadEvents() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    App.events = raw ? JSON.parse(raw) : [];
  } catch {
    App.events = [];
  }
}

/** Salva eventos no localStorage */
function saveEvents() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(App.events));
}

/* ============================================================
   CRUD DE EVENTOS
   ============================================================ */

/** Adiciona ou atualiza evento */
function saveEvent(data) {
  if (App.editingId) {
    // Atualizar
    const idx = App.events.findIndex(e => e.id === App.editingId);
    if (idx !== -1) {
      App.events[idx] = { ...App.events[idx], ...data, updatedAt: Date.now() };
    }
    App.editingId = null;
    showToast('Evento atualizado com sucesso!', 'success');
  } else {
    // Criar
    const ev = {
      id: uid(),
      ...data,
      done: false,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    App.events.push(ev);
    showToast('Evento criado com sucesso!', 'success');
  }
  saveEvents();
  refreshAll();
}

/** Marca/desmarca como concluído */
function toggleDone(id) {
  const ev = App.events.find(e => e.id === id);
  if (!ev) return;
  ev.done = !ev.done;
  ev.updatedAt = Date.now();
  saveEvents();
  refreshAll();
  showToast(ev.done ? 'Evento marcado como concluído!' : 'Evento reaberto.', 'info');
}

/** Remove evento */
function deleteEvent(id) {
  if (!confirm('Tem certeza que deseja excluir este evento?')) return;
  App.events = App.events.filter(e => e.id !== id);
  saveEvents();
  refreshAll();
  showToast('Evento removido.', 'warn');
}

/** Abre modal para editar evento */
function editEvent(id) {
  const ev = App.events.find(e => e.id === id);
  if (!ev) return;
  App.editingId = id;
  openModal(ev);
}

/* ============================================================
   RENDERIZAÇÃO — CARTÃO DE EVENTO
   ============================================================ */

/**
 * Cria o elemento HTML de um cartão de evento.
 * @param {Object} ev  Objeto do evento
 * @returns {HTMLElement}
 */
function createEventCard(ev) {
  const status = eventStatus(ev);
  const days = daysUntil(ev.date);

  const card = document.createElement('div');
  card.className = `event-card${ev.done ? ' done' : ''}${status === 'overdue' ? ' overdue' : ''}`;
  card.dataset.id = ev.id;

  // Label de prazo
  let daysLabel = '';
  if (!ev.done) {
    if (days === 0) daysLabel = 'Hoje!';
    else if (days === 1) daysLabel = 'Amanhã';
    else if (days > 0 && days <= 7) daysLabel = `Em ${days} dias`;
    else if (days < 0) daysLabel = `${Math.abs(days)}d atrasado`;
  }

  // HTML interno
  card.innerHTML = `
    <div class="event-type-dot dot-${ev.type || 'outro'}"></div>
    <div class="event-card-body">
      <div class="event-card-title">${escapeHtml(ev.title)}</div>
      <div class="event-card-meta">
        <span class="event-tag tag-${ev.type || 'outro'}">${TYPE_LABELS[ev.type] || cap(ev.type)}</span>
        ${status === 'overdue' && !ev.done ? '<span class="event-tag tag-overdue">Atrasado</span>' : ''}
        <span class="event-date">
          <i data-lucide="calendar"></i>
          ${formatDate(ev.date)}${ev.time ? ' · ' + formatTime(ev.time) : ''}
        </span>
        <span class="event-discipline">${escapeHtml(ev.discipline)}</span>
        ${daysLabel && !ev.done ? `<span class="event-date" style="color:${days < 0 ? 'var(--prova)' : days <= 2 ? 'var(--apresentacao)' : 'var(--accent-3)'}">${daysLabel}</span>` : ''}
      </div>
    </div>
    <div class="event-card-actions">
      <button class="card-action-btn done" title="${ev.done ? 'Reabrir' : 'Concluir'}" data-action="done" data-id="${ev.id}">
        <i data-lucide="${ev.done ? 'rotate-ccw' : 'check'}"></i>
      </button>
      <button class="card-action-btn edit" title="Editar" data-action="edit" data-id="${ev.id}">
        <i data-lucide="pencil"></i>
      </button>
      <button class="card-action-btn delete" title="Excluir" data-action="delete" data-id="${ev.id}">
        <i data-lucide="trash-2"></i>
      </button>
    </div>
  `;

  return card;
}

/** Escapa HTML para evitar XSS */
function escapeHtml(str) {
  return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/* ============================================================
   RENDERIZAÇÃO — DASHBOARD
   ============================================================ */

function renderDashboard() {
  const disciplineVal = App.filters.discipline;
  const allEvents = disciplineVal
    ? App.events.filter(e => e.discipline === disciplineVal)
    : App.events;

  const now7 = allEvents.filter(e => {
    if (e.done) return false;
    const d = daysUntil(e.date);
    return d !== null && d >= 0 && d <= 7;
  });
  const overdue = allEvents.filter(e => !e.done && daysUntil(e.date) < 0);
  const done = allEvents.filter(e => e.done);

  // Summary cards
  document.getElementById('sumTotal').textContent    = allEvents.length;
  document.getElementById('sumUpcoming').textContent = now7.length;
  document.getElementById('sumOverdue').textContent  = overdue.length;
  document.getElementById('sumDone').textContent     = done.length;

  // Badges
  document.getElementById('badgeUpcoming').textContent = now7.length;
  document.getElementById('badgeOverdue').textContent  = overdue.length;

  // Upcoming list
  renderEventList('upcomingList', now7.sort((a, b) => new Date(a.date) - new Date(b.date)));

  // Overdue list
  renderEventList('overdueList', overdue.sort((a, b) => new Date(a.date) - new Date(b.date)));
}

/** Renderiza lista de eventos num container */
function renderEventList(containerId, events) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = '';

  if (!events.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    empty.innerHTML = `<i data-lucide="inbox"></i><p>Nenhum evento aqui.</p>`;
    container.appendChild(empty);
    lucide.createIcons();
    return;
  }

  events.forEach(ev => {
    const card = createEventCard(ev);
    container.appendChild(card);
  });

  // Re-inicializa ícones Lucide dentro dos novos cards
  lucide.createIcons();
}

/* ============================================================
   RENDERIZAÇÃO — LISTA COMPLETA DE EVENTOS
   ============================================================ */

function renderAllEvents() {
  const { search, type, status, discipline } = App.filters;
  const list = document.getElementById('allEventsList');
  if (!list) return;

  let filtered = [...App.events];

  // Filtro disciplina (sidebar)
  if (discipline) filtered = filtered.filter(e => e.discipline === discipline);

  // Filtro busca
  if (search) {
    const q = search.toLowerCase();
    filtered = filtered.filter(e =>
      e.title.toLowerCase().includes(q) ||
      e.discipline.toLowerCase().includes(q) ||
      (e.description || '').toLowerCase().includes(q)
    );
  }

  // Filtro tipo
  if (type) filtered = filtered.filter(e => e.type === type);

  // Filtro status
  if (status) {
    filtered = filtered.filter(e => {
      const s = eventStatus(e);
      if (status === 'pending')  return s === 'pending';
      if (status === 'done')     return s === 'done';
      if (status === 'overdue')  return s === 'overdue';
      return true;
    });
  }

  // Ordenar por data
  filtered.sort((a, b) => new Date(a.date) - new Date(b.date));

  list.innerHTML = '';

  if (!filtered.length) {
    list.innerHTML = `
      <div class="empty-state">
        <i data-lucide="search-x"></i>
        <p>Nenhum evento encontrado com esses filtros.</p>
      </div>`;
    lucide.createIcons();
    return;
  }

  filtered.forEach(ev => list.appendChild(createEventCard(ev)));
  lucide.createIcons();
}

/* ============================================================
   RENDERIZAÇÃO — FILTRO DE DISCIPLINAS
   ============================================================ */

function renderDisciplineFilter() {
  const sel = document.getElementById('disciplineFilter');
  if (!sel) return;

  // Coleta disciplinas únicas
  const disciplines = [...new Set(App.events.map(e => e.discipline).filter(Boolean))].sort();

  sel.innerHTML = '<option value="">Todas as disciplinas</option>';
  disciplines.forEach(d => {
    const opt = document.createElement('option');
    opt.value = d;
    opt.textContent = d;
    if (d === App.filters.discipline) opt.selected = true;
    sel.appendChild(opt);
  });
}

/* ============================================================
   RENDERIZAÇÃO — ESTATÍSTICAS
   ============================================================ */

function renderStats() {
  renderChartByType();
  renderChartByDiscipline();
  renderTimeline();
}

function renderChartByType() {
  const container = document.getElementById('chartByType');
  if (!container) return;

  const types = ['prova', 'trabalho', 'entrega', 'apresentacao', 'outro'];
  const colors = {
    prova: 'var(--prova)',
    trabalho: 'var(--trabalho)',
    entrega: 'var(--entrega)',
    apresentacao: 'var(--apresentacao)',
    outro: 'var(--outro)',
  };

  const counts = {};
  types.forEach(t => { counts[t] = App.events.filter(e => e.type === t).length; });
  const max = Math.max(...Object.values(counts), 1);

  container.innerHTML = types.map(t => `
    <div class="bar-row">
      <span class="bar-label">${TYPE_LABELS[t]}</span>
      <div class="bar-track">
        <div class="bar-fill" style="width:${(counts[t]/max)*100}%; background:${colors[t]}"></div>
      </div>
      <span class="bar-count">${counts[t]}</span>
    </div>
  `).join('');
}

function renderChartByDiscipline() {
  const container = document.getElementById('chartByDiscipline');
  if (!container) return;

  const disciplines = [...new Set(App.events.map(e => e.discipline).filter(Boolean))].sort();

  if (!disciplines.length) {
    container.innerHTML = `<p style="color:var(--text-muted);font-size:.85rem">Nenhum dado ainda.</p>`;
    return;
  }

  const counts = {};
  disciplines.forEach(d => { counts[d] = App.events.filter(e => e.discipline === d).length; });
  const max = Math.max(...Object.values(counts), 1);

  container.innerHTML = disciplines.slice(0, 8).map((d, i) => `
    <div class="bar-row">
      <span class="bar-label" title="${escapeHtml(d)}" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHtml(d)}</span>
      <div class="bar-track">
        <div class="bar-fill" style="width:${(counts[d]/max)*100}%; background:hsl(${(i*47)%360},65%,55%)"></div>
      </div>
      <span class="bar-count">${counts[d]}</span>
    </div>
  `).join('');
}

function renderTimeline() {
  const container = document.getElementById('timelineChart');
  if (!container) return;

  // Últimos 14 dias
  const days = 14;
  const buckets = Array.from({ length: days }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (days - 1 - i));
    d.setHours(0, 0, 0, 0);
    return d;
  });

  const counts = buckets.map(day => {
    return App.events.filter(e => {
      const ed = parseDate(e.date);
      return ed && ed.getTime() === day.getTime();
    }).length;
  });

  const max = Math.max(...counts, 1);

  container.innerHTML = counts.map((c, i) => {
    const label = buckets[i].toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
    const pct = Math.max((c / max) * 80, c > 0 ? 8 : 2);
    return `
      <div class="timeline-bar" style="height:${pct}px" title="${label}: ${c} evento(s)">
        <span class="timeline-bar-label">${label}</span>
      </div>
    `;
  }).join('');
}

/* ============================================================
   ATUALIZA TUDO
   ============================================================ */

function refreshAll() {
  renderDisciplineFilter();
  if (App.currentView === 'dashboard') renderDashboard();
  if (App.currentView === 'events')    renderAllEvents();
  if (App.currentView === 'calendar')  window.CalendarModule && CalendarModule.render();
  if (App.currentView === 'stats')     renderStats();
}

/* ============================================================
   MODAL DE EVENTO
   ============================================================ */

function openModal(ev = null) {
  const backdrop = document.getElementById('modalBackdrop');
  const title    = document.getElementById('modalTitle');
  const form     = document.getElementById('eventForm');

  // Reset form
  form.reset();
  document.querySelectorAll('input[name="reminder"]').forEach(cb => cb.checked = false);
  document.getElementById('customReminderWrap').classList.remove('visible');

  if (ev) {
    // Preenche para edição
    title.textContent = 'Editar evento';
    document.getElementById('eventId').value        = ev.id;
    document.getElementById('evTitle').value        = ev.title || '';
    document.getElementById('evDiscipline').value   = ev.discipline || '';
    document.getElementById('evType').value         = ev.type || '';
    document.getElementById('evDate').value         = ev.date || '';
    document.getElementById('evTime').value         = ev.time || '';
    document.getElementById('evDescription').value  = ev.description || '';

    // Lembretes
    (ev.reminders || []).forEach(r => {
      if (r === 'custom') {
        document.getElementById('reminderCustomCheck').checked = true;
        document.getElementById('customReminderWrap').classList.add('visible');
        document.getElementById('evCustomReminder').value = ev.customReminder || '';
      } else {
        const cb = document.querySelector(`input[name="reminder"][value="${r}"]`);
        if (cb) cb.checked = true;
      }
    });
  } else {
    title.textContent = 'Novo evento';
    document.getElementById('eventId').value = '';
    App.editingId = null;
  }

  backdrop.classList.add('open');
  document.getElementById('evTitle').focus();
}

function closeModal() {
  document.getElementById('modalBackdrop').classList.remove('open');
  App.editingId = null;
}

/* ============================================================
   SUBMISSÃO DO FORMULÁRIO
   ============================================================ */

function handleFormSubmit() {
  const title      = document.getElementById('evTitle').value.trim();
  const discipline = document.getElementById('evDiscipline').value.trim();
  const type       = document.getElementById('evType').value;
  const date       = document.getElementById('evDate').value;
  const time       = document.getElementById('evTime').value;
  const description = document.getElementById('evDescription').value.trim();

  // Validação básica
  if (!title) { showToast('Informe o título do evento.', 'error'); return; }
  if (!discipline) { showToast('Informe a disciplina.', 'error'); return; }
  if (!type) { showToast('Selecione o tipo do evento.', 'error'); return; }
  if (!date) { showToast('Informe a data do evento.', 'error'); return; }

  // Lembretes selecionados
  const reminders = [];
  document.querySelectorAll('input[name="reminder"]:checked').forEach(cb => {
    reminders.push(cb.value);
  });
  const customReminder = document.getElementById('evCustomReminder').value || null;

  const data = { title, discipline, type, date, time, description, reminders, customReminder };

  // Agenda lembretes via módulo de notificações
  if (window.NotificationsModule) {
    NotificationsModule.scheduleReminders(data);
  }

  saveEvent(data);
  closeModal();
}

/* ============================================================
   NAVEGAÇÃO ENTRE VIEWS
   ============================================================ */

function switchView(view) {
  App.currentView = view;

  // Nav items
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.view === view);
  });

  // Sections
  document.querySelectorAll('.view').forEach(el => {
    el.classList.toggle('active', el.id === `view-${view}`);
  });

  // Título
  const titles = {
    dashboard: 'Dashboard',
    events: 'Eventos',
    calendar: 'Calendário',
    stats: 'Estatísticas',
  };
  document.getElementById('pageTitle').textContent = titles[view] || view;

  // Renderiza a view
  if (view === 'dashboard') renderDashboard();
  if (view === 'events')    renderAllEvents();
  if (view === 'calendar')  window.CalendarModule && CalendarModule.render();
  if (view === 'stats')     renderStats();
}

/* ============================================================
   TOAST NOTIFICATIONS
   ============================================================ */

/**
 * Exibe um toast na tela.
 * @param {string} message  Mensagem
 * @param {'success'|'error'|'info'|'warn'} type
 */
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  const icons = {
    success: 'check-circle-2',
    error:   'x-circle',
    info:    'info',
    warn:    'alert-triangle',
  };

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `<i data-lucide="${icons[type] || 'info'}"></i><span>${escapeHtml(message)}</span>`;

  container.appendChild(toast);
  lucide.createIcons({ nodes: [toast] });

  // Remove após 3.5s
  setTimeout(() => {
    toast.classList.add('removing');
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

/* ============================================================
   DARK MODE
   ============================================================ */

function initDarkMode() {
  const saved = localStorage.getItem('studyflow_theme') || 'light';
  setTheme(saved);

  document.getElementById('darkToggle').addEventListener('click', () => {
    const current = document.documentElement.dataset.theme;
    setTheme(current === 'dark' ? 'light' : 'dark');
  });
}

function setTheme(theme) {
  document.documentElement.dataset.theme = theme;
  localStorage.setItem('studyflow_theme', theme);

  const btn = document.getElementById('darkToggle');
  if (!btn) return;
  const icon = theme === 'dark' ? 'sun' : 'moon';
  const text = theme === 'dark' ? 'Modo claro' : 'Modo escuro';
  btn.innerHTML = `<i data-lucide="${icon}"></i><span>${text}</span>`;
  lucide.createIcons({ nodes: [btn] });
}

/* ============================================================
   DELEGAÇÃO DE EVENTOS NAS LISTAS
   ============================================================ */

function bindListActions() {
  // Delegação global para ações dos cards
  document.addEventListener('click', e => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const { action, id } = btn.dataset;
    if (action === 'done')   toggleDone(id);
    if (action === 'edit')   editEvent(id);
    if (action === 'delete') deleteEvent(id);
  });
}

/* ============================================================
   INICIALIZAÇÃO
   ============================================================ */

function init() {
  // Carrega dados
  loadEvents();

  // Dark mode
  initDarkMode();

  // Renderiza view inicial
  switchView('dashboard');

  // Inicializa ícones Lucide
  lucide.createIcons();

  // ——— Botões topbar ———
  document.getElementById('btnNewEvent').addEventListener('click', () => openModal());
  document.getElementById('btnGoogleSync').addEventListener('click', () => {
    document.getElementById('googleModalBackdrop').classList.add('open');
  });

  // ——— Modal evento ———
  document.getElementById('modalClose').addEventListener('click', closeModal);
  document.getElementById('btnCancelModal').addEventListener('click', closeModal);
  document.getElementById('btnSaveEvent').addEventListener('click', handleFormSubmit);
  document.getElementById('modalBackdrop').addEventListener('click', e => {
    if (e.target === document.getElementById('modalBackdrop')) closeModal();
  });

  // Lembrete personalizado toggle
  document.getElementById('reminderCustomCheck').addEventListener('change', function() {
    document.getElementById('customReminderWrap').classList.toggle('visible', this.checked);
  });

  // ——— Modal Google ———
  document.getElementById('googleModalClose').addEventListener('click', () => {
    document.getElementById('googleModalBackdrop').classList.remove('open');
  });
  document.getElementById('googleModalBackdrop').addEventListener('click', e => {
    if (e.target === document.getElementById('googleModalBackdrop'))
      document.getElementById('googleModalBackdrop').classList.remove('open');
  });

  // ——— Navegação sidebar ———
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', e => {
      e.preventDefault();
      switchView(item.dataset.view);
      // Fecha sidebar em mobile
      closeSidebar();
    });
  });

  // ——— Menu mobile ———
  document.getElementById('menuBtn').addEventListener('click', openSidebar);
  document.getElementById('sidebarClose').addEventListener('click', closeSidebar);
  document.getElementById('overlay').addEventListener('click', closeSidebar);

  // ——— Filtros ———
  document.getElementById('disciplineFilter').addEventListener('change', e => {
    App.filters.discipline = e.target.value;
    refreshAll();
  });

  document.getElementById('searchInput').addEventListener('input', e => {
    App.filters.search = e.target.value;
    renderAllEvents();
  });

  document.getElementById('typeFilter').addEventListener('change', e => {
    App.filters.type = e.target.value;
    renderAllEvents();
  });

  document.getElementById('statusFilter').addEventListener('change', e => {
    App.filters.status = e.target.value;
    renderAllEvents();
  });

  // ——— Delegação de ações nas listas ———
  bindListActions();

  // ——— Verificação de lembretes ao abrir ———
  if (window.NotificationsModule) {
    NotificationsModule.requestPermission();
    NotificationsModule.checkReminders();
  }
}

/* ——— Sidebar mobile ——— */
function openSidebar() {
  document.getElementById('sidebar').classList.add('open');
  document.getElementById('overlay').classList.add('active');
  document.body.style.overflow = 'hidden';
}
function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('overlay').classList.remove('active');
  document.body.style.overflow = '';
}

// Inicializa quando DOM estiver pronto
document.addEventListener('DOMContentLoaded', init);

// Exposição global para uso nos outros módulos
window.AppState = App;
window.showToast = showToast;
window.AppEvents = {
  getEvents: () => App.events,
  parseDate,
  formatDate,
  daysUntil,
  eventStatus,
  TYPE_LABELS,
  refreshAll,
};