/**
 * notifications.js — StudyFlow
 * Gerencia lembretes e notificações do navegador (Web Notifications API).
 *
 * Fluxo:
 *  1. Ao salvar um evento com lembretes, agendamos no localStorage.
 *  2. Ao iniciar o app (e periodicamente), verificamos se algum lembrete
 *     deve disparar agora e exibimos a notificação.
 */

const NotificationsModule = (() => {

  /* ============================================================
     CHAVE DE ARMAZENAMENTO
     ============================================================ */
  const REMINDERS_KEY = 'studyflow_reminders'; // array de { id, eventId, fireAt, fired }

  /* ============================================================
     PERMISSÃO
     ============================================================ */

  /**
   * Solicita permissão de notificação ao usuário.
   * Chamado na inicialização do app.
   */
  async function requestPermission() {
    if (!('Notification' in window)) {
      console.warn('[Notifications] Web Notifications não suportado neste browser.');
      return;
    }
    if (Notification.permission === 'default') {
      const result = await Notification.requestPermission();
      if (result === 'granted') {
        showToast('Notificações ativadas!', 'success');
      }
    }
  }

  /* ============================================================
     SALVAR / CARREGAR LEMBRETES AGENDADOS
     ============================================================ */

  function loadScheduled() {
    try {
      const raw = localStorage.getItem(REMINDERS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  function saveScheduled(list) {
    localStorage.setItem(REMINDERS_KEY, JSON.stringify(list));
  }

  /* ============================================================
     AGENDAR LEMBRETES PARA UM EVENTO
     ============================================================ */

  /**
   * Registra os lembretes de um evento no localStorage.
   * @param {Object} eventData  Dados do evento (title, date, time, reminders, customReminder, id?)
   */
  function scheduleReminders(eventData) {
    if (!eventData.reminders || !eventData.reminders.length) return;
    if (!eventData.date) return;

    // Monta timestamp do evento
    const eventDateTime = buildEventTimestamp(eventData.date, eventData.time);
    if (!eventDateTime) return;

    let scheduled = loadScheduled();

    // Remove lembretes anteriores deste evento (re-agendamento ao editar)
    const eventId = eventData.id || eventData.title; // usa id se edição, título se novo
    scheduled = scheduled.filter(r => r.eventId !== eventId);

    eventData.reminders.forEach(r => {
      if (r === 'custom') {
        if (eventData.customReminder) {
          const fireAt = new Date(eventData.customReminder).getTime();
          if (!isNaN(fireAt)) {
            scheduled.push({
              id: `${eventId}_custom`,
              eventId,
              eventTitle: eventData.title,
              eventDiscipline: eventData.discipline,
              fireAt,
              fired: false,
            });
          }
        }
      } else {
        const days = parseInt(r, 10);
        if (!isNaN(days)) {
          const fireAt = eventDateTime - days * 86400000;
          if (fireAt > Date.now()) {
            scheduled.push({
              id: `${eventId}_${days}d`,
              eventId,
              eventTitle: eventData.title,
              eventDiscipline: eventData.discipline,
              daysBeforeLabel: days,
              fireAt,
              fired: false,
            });
          }
        }
      }
    });

    saveScheduled(scheduled);
    console.log(`[Notifications] ${scheduled.length} lembrete(s) agendado(s) no total.`);
  }

  /**
   * Converte data string + hora opcional em timestamp (ms).
   * @param {string} dateStr  'YYYY-MM-DD'
   * @param {string} timeStr  'HH:MM' (opcional)
   */
  function buildEventTimestamp(dateStr, timeStr) {
    const [y, m, d] = dateStr.split('-').map(Number);
    if (!y || !m || !d) return null;

    if (timeStr) {
      const [hh, mm] = timeStr.split(':').map(Number);
      return new Date(y, m - 1, d, hh || 0, mm || 0, 0, 0).getTime();
    }
    return new Date(y, m - 1, d, 8, 0, 0, 0).getTime(); // padrão 08:00
  }

  /* ============================================================
     VERIFICAR E DISPARAR LEMBRETES
     ============================================================ */

  /**
   * Verifica se algum lembrete agendado deve ser disparado agora.
   * Chamado ao iniciar o app e a cada minuto.
   */
  function checkReminders() {
    const now = Date.now();
    let scheduled = loadScheduled();
    let changed = false;

    scheduled.forEach(r => {
      if (!r.fired && r.fireAt <= now) {
        fireReminder(r);
        r.fired = true;
        changed = true;
      }
    });

    if (changed) saveScheduled(scheduled);
  }

  /**
   * Dispara uma notificação do navegador.
   * @param {Object} reminder
   */
  function fireReminder(reminder) {
    const { eventTitle, eventDiscipline, daysBeforeLabel } = reminder;

    let body = `Disciplina: ${eventDiscipline}`;
    let title = `📚 Lembrete: ${eventTitle}`;

    if (daysBeforeLabel === 1) {
      body = `Este evento é AMANHÃ! — ${eventDiscipline}`;
    } else if (daysBeforeLabel) {
      body = `Em ${daysBeforeLabel} dia(s) — ${eventDiscipline}`;
    }

    // Toast interno sempre
    showToast(`🔔 Lembrete: ${eventTitle}`, 'warn');

    // Notificação nativa do browser (se permitida)
    if (Notification.permission === 'granted') {
      try {
        const notif = new Notification(title, {
          body,
          icon: '../assets/icons/icon-192.png',
          badge: '../assets/icons/icon-192.png',
          tag: reminder.id, // evita duplicatas
          requireInteraction: false,
        });

        notif.onclick = () => {
          window.focus();
          notif.close();
        };

        setTimeout(() => notif.close(), 10000);
      } catch (e) {
        console.warn('[Notifications] Erro ao criar notificação:', e);
      }
    }
  }

  /* ============================================================
     VERIFICAÇÃO PERIÓDICA (a cada 60s)
     ============================================================ */
  setInterval(checkReminders, 60 * 1000);

  /* ============================================================
     LIMPAR LEMBRETES DE UM EVENTO (ao excluir)
     ============================================================ */

  /**
   * Remove todos os lembretes agendados de um evento específico.
   * @param {string} eventId
   */
  function clearEventReminders(eventId) {
    let scheduled = loadScheduled();
    scheduled = scheduled.filter(r => r.eventId !== eventId);
    saveScheduled(scheduled);
  }

  /* ============================================================
     EXPOSIÇÃO PÚBLICA
     ============================================================ */
  return {
    requestPermission,
    scheduleReminders,
    checkReminders,
    clearEventReminders,
  };

})();

// Disponibiliza globalmente
window.NotificationsModule = NotificationsModule;