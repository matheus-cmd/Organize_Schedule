# 📅 Schedule Organize

Aplicação web para auxiliar estudantes na organização de atividades acadêmicas.

## 🚀 Como usar

Basta abrir o arquivo `index.html` em qualquer navegador moderno. Não precisa de servidor.

---

## 📁 Estrutura do Projeto

```
schedule-organize/
├── index.html                 → Estrutura da página (HTML)
├── css/
│   └── style.css              → Estilos visuais (CSS)
├── javascript/
│   ├── app.js                 → Lógica principal (navegação, eventos, renderização)
│   ├── storage.js             → Funções de salvar/carregar no localStorage
│   └── weather.js             → Integração com a API Open-Meteo (clima)
└── README.md                  → Este arquivo
```

---

## ✨ Funcionalidades

### Dashboard
- Exibe a data atual
- Card de clima com temperatura e mensagem contextual para o dia
- Estatísticas: total, pendentes, atrasadas e concluídas
- Lista de atividades atrasadas
- Lista das atividades dos próximos 7 dias

### Gerenciamento de Atividades
- Cadastro com: título, disciplina, tipo, data e horário
- Editar qualquer atividade
- Excluir com confirmação
- Marcar como concluída (checkbox)

### Filtros e Busca
- Busca por título ou disciplina
- Filtro por tipo (prova, trabalho, atividade, apresentação)
- Filtro por disciplina (populado automaticamente)
- Filtro por status (pendente, concluída, atrasada)

### Extras
- 🌙 Modo escuro
- 💾 Dados salvos automaticamente no localStorage

---

## 🌐 APIs Utilizadas

### Open-Meteo (clima)
- URL: `https://api.open-meteo.com/v1/forecast`
- Gratuita, sem necessidade de chave de API
- Parâmetros usados: `temperature_2m`, `weathercode`
- Documentação: https://open-meteo.com

---

## 💡 Conceitos Aplicados

| Conceito                  | Onde é usado                             |
|---------------------------|------------------------------------------|
| Manipulação do DOM        | `app.js` — criar, inserir e remover cards |
| Eventos JavaScript        | `app.js` — click, change, keydown        |
| Arrays e Objetos          | `storage.js` e `app.js`                 |
| LocalStorage              | `storage.js`                             |
| Funções e Modularização   | Separação em 3 arquivos JS               |
| Fetch API (assíncrono)    | `weather.js` — async/await              |
| Responsividade            | `style.css` — media queries             |

---

## 👨‍💻 Tecnologias

- HTML5
- CSS3 (variáveis CSS, Flexbox, Grid, animações)
- JavaScript (ES6+)
- LocalStorage
- Fetch API
- Open-Meteo API
